tabacc
======

A jQuery plugin that simplifies creating responsive tabs and accordions.
